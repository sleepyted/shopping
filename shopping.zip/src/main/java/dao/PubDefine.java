package dao;

/**
 * Created by matengfei1 on 2018/4/10.
 */
public interface PubDefine {
    int STATUS_ERROR = -2;
    int STATUS_NOT_FOUND = -1;
    int STATUS_ALLREADY_FOUND = -4;
}
